
from distutils.core import setup

setup(
	name='ezprint',
	version='0.2',
	packages=['ezprint'],
	url='https://github.com/danilpresent/ezprint',
	author='danilpresent',
	author_email='danil.present@mail.com',
	description='Easy print',
	keywords='print',
)
