
from distutils.core import setup

setup(
	name='ezprint',
	version='0.3.1',
	packages=['ezprint'],
	url='https://github.com/danilpresent/ezprint',
	author='danilpresent',
	author_email='danil.present@mail.com',
	description='Easy print',
	keywords='print',
)
