
from ezprint.ezprint import p, pwi, pwd, cls
