
def p(value):
	print(value)