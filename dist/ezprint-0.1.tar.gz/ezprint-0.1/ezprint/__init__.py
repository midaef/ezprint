
from ezprint.ezprint import p
